public interface DictionarySource {

    boolean isValidWord(String word);
}
