import java.util.List;

public interface Extractor {

    List<String> extract(String content);
}
